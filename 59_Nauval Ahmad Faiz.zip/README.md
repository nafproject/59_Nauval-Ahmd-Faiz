# TugasJarkom

TUTORIALLLLLLl
https://youtu.be/crqnkGpIhOM
https://youtu.be/crqnkGpIhOM
https://youtu.be/crqnkGpIhOM
https://youtu.be/crqnkGpIhOM
