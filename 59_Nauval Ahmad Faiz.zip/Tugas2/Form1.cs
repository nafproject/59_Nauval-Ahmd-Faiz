
namespace Tugas2;

public partial class Form1 : Form
{
    public Form1()
    {
        
        InitializeComponent();
        // MOForm1 form = new MOForm1();
        // form.Show();
    }
}